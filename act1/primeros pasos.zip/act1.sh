#!/bin/bash

##### Opciones por defecto
filename=~/sysinfo.txt

##### Constantes
TITLE="Información del sistema para $HOSTNAME" # $HOSTNAME muestra el nombre del host
RIGHT_NOW=$(date +"%x %r%Z") # date muestra la fecha y hora actual
TIME_STAMP="Actualizada el $RIGHT_NOW por $USER" # muestra el nombre del usuario actual con la fecha y hora actual

##### Estilos

TEXT_BOLD=$(tput bold) # tput bold hace que el texto sea negrita
TEXT_GREEN=$(tput setaf 2) # tput setaf 2 hace que el texto sea verde
TEXT_RESET=$(tput sgr0) # tput sgr0 hace que el texto sea normal
TEXT_ULINE=$(tput sgr 0 1) # tput sgr 0 1 hace que el texto sea subrayado

##### Funciones



usage()
{
  echo "Usage: scdebug [-h] [-sto arg] [-v | -vall] [-nattch progtoattach] [prog [arg1 …]]"
}

shift(){
  echo "shift"
}

verbose(){
  echo "verbose"
}

nache(){
  echo "nache $filename"
}

programa(){
  echo "programa"
}

if [ $# -eq 0 ]; then
  usage
  exit 1
fi

# Procesar la línea de comandos del script para leer del script las opciones
while [ "$1" != "" ]; do
  case $1 in
    -h | --help )           
      usage
      exit
      ;;
    -sto | --stop )
      shift
      exit
      ;;
    -v | -vall )            
      verbose
      exit
      ;;
    -nattche )           
      filename=$2
      nache
      exit
      ;;
    prog )
      programa
      exit
      ;;
    * )
      usage
      exit 1
    esac
    shift # elimina el argumento que se acaba de procesar de la lista de argumentos
done